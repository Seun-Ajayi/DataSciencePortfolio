from setuptools import setup

setup(name='probable',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['probable'],
      author= 'Oluwaseun Ajayi',
      author_email= 'oluwaseunaajayi@student.oauife.edu.ng',
      zip_safe=False)
